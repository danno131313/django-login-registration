from django.shortcuts import render, redirect
from .models import User
from django.contrib import messages

def index(request):
    return render(request, "user_login/index.html")

def create(request):
    errors = User.objects.validator(request.POST)

    if errors:
        for error in errors:
            messages.error(request, errors[error])
        return redirect('/user_login')
    
    else:
        messages.success(request, "Successfully created new user!")
        
        first_name    = request.POST['first_name']
        last_name     = request.POST['last_name']
        email_address = request.POST['email_address']
        age           = request.POST['age']
        
        User.objects.create(first_name=first_name, last_name=last_name, email_address=email_address, age=age)
    return redirect('/user_login/show')

def show(request):
    context = {
        'users': User.objects.all(),
    }
    return render(request, "user_login/show.html", context)
